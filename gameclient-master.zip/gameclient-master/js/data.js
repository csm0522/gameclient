var users = [
	{
		nickname : "玩家一",
		id : null,
		win : 0,
		total : 0,
		status : 1
	},{
		nickname : "玩家一",
		id : null,
		win : 0,
		total : 0,
		status : 1
	},
	{
		nickname : "玩家一",
		id : null,
		win : 0,
		total : 0,
		status : 1
	},
	{
		nickname : "玩家一",
		id : null,
		win : 0,
		total : 0,
		status : 1
	},
	{
		nickname : "玩家一",
		id : null,
		win : 0,
		total : 0,
		status : 1
	},
	{
		nickname : "玩家一",
		id : null,
		win : 0,
		total : 0,
		status : 1
	}
]
var rooms = [
	{roomname:'输光光'},
	{roomname:'输光光'},
	{roomname:'输光光'},
	{roomname:'输光光'},
	{roomname:'输光光'},
	{roomname:'输光光'}
]